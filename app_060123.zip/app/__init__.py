from flask_login import LoginManager
from flask import Flask
from flask_babelex import Babel
from flask_sqlalchemy import SQLAlchemy
from app.routes import main_bp


app = Flask(__name__)
# if app.config['ENV'] == 'production':
#     app.config.from_object('config.ProductionConfig')
# elif app.config['ENV'] == 'testing':
#     app.config.from_object('config.TestingConfig')
# else:
#     app.config.from_object('config.DebugConfig')
app.config.from_object('config.DebugConfig')


db = SQLAlchemy(app)
babel = Babel(app)


@babel.localeselector
def get_locale():
    return 'ru'

login_manager = LoginManager(app)
login_manager.login_view = 'admin_blueprint.login'

app.register_blueprint(main_bp, url_prefix="/")

from app.admin.routes import admin_bp
app.register_blueprint(admin_bp, url_prefix="/admin")


